﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentASE
{
    public class Painter
    {
        Graphics g;
        Bitmap bitmap;
        Bitmap tempBit;
        Pen pen;
        String log;
        Pen cursorPen = new Pen(Color.Red);
        System.Windows.Forms.RichTextBox logBox;
        bool fill;
        ShapeFactory shapes;
        CommandFactory commands;
        int xPos;
        int yPos;
        System.Drawing.SolidBrush brush;
        System.Windows.Forms.PictureBox outputWindow;

        public int XPos
        {
            get { return xPos; }
            set { xPos = value; }
        }

        public int YPos
        {
            get { return yPos; }
            set { yPos = value; }
        }

        public String Pen
        {
            get { return pen.Color.Name; }
        }

        public bool Fill
        {
            get { return fill; }
        }

        public Painter()
        {
            xPos = yPos = 0;
            log = "";
            pen = new Pen(Color.Black, 1);
            brush = new SolidBrush(Color.Black);
            g = Graphics.FromImage(new Bitmap(400, 400));
        }

        public Painter(System.Windows.Forms.PictureBox outputWindow, System.Windows.Forms.RichTextBox logBox)
        {
            this.logBox = logBox;
            this.outputWindow = outputWindow;

            bitmap = new Bitmap(outputWindow.Width, outputWindow.Height);
            tempBit = new Bitmap(outputWindow.Width, outputWindow.Height);

            this.outputWindow.Image = bitmap;

            this.g = Graphics.FromImage(bitmap);

            xPos = yPos = 0;
            this.log = "";
            fill = false;

            shapes = new ShapeFactory();
            commands = new CommandFactory();
            pen = new Pen(Color.Black, 1);

            brush = new SolidBrush(Color.Black);
            DrawCursor();
        }

        public void Center()
        {
            xPos = outputWindow.Width / 2;
            yPos = outputWindow.Height / 2;
            log += "[" + DateTime.Now.ToString("T") + "] " + "Cursor centered in the drawing area.\r\n";
        }


        public void SetColor(String color)
        {
            bool isColorValid = false;
            foreach (KnownColor _color in Enum.GetValues(typeof(KnownColor)))
            {
                if (_color.ToString().ToUpper().Equals(color.ToUpper()))
                {
                    isColorValid = true;
                    break;
                }

            }
            if (isColorValid)
            {
                pen.Color = Color.FromName(color);
                brush.Color = Color.FromName(color);
                log += "[" + DateTime.Now.ToString("T") + "] " + "Pen and Brush color set to " + color + ".\r\n";

            }
            else
            {
                throw new Exception("Color not found");
            }
        }

        public void SetFill(String flag)
        {
            if (flag == "on")
            {
                fill = true;
                log += "[" + DateTime.Now.ToString("T") + "] " + "Set the drawing shapes to be filled.\r\n";
            }
            else
            {
                fill = false;
                log += "[" + DateTime.Now.ToString("T") + "] " + "Set the drawing shapes to be outlined.\r\n";
            }
        }

        public void DrawCursor()
        {
            outputWindow.Image = tempBit;
            g = Graphics.FromImage(outputWindow.Image);
            g.DrawLine(cursorPen, xPos + 6, yPos, xPos - 6, yPos);
            g.DrawLine(cursorPen, xPos, yPos + 6, xPos, yPos - 6);
        }

        public void updateImage()
        {
            outputWindow.Image = bitmap;
            g = Graphics.FromImage(outputWindow.Image);
        }

        public void storeTempImage()
        {
            tempBit = new Bitmap(bitmap);
        }

        public void ExecuteCommand(string commandType, params int[] p)
        {
            int[] list = new int[p.Length + 2];
            list[0] = xPos;
            list[1] = yPos;
            for (int i = 2; i < list.Length; i++)
                list[i] = p[i - 2];
            Command command = commands.getCommand(commandType);
            command.set(g, pen, list);
            command.execute();
            this.xPos = command.X;
            this.yPos = command.Y;
            log += command.getLog();
        }

        public void WhileLoop()
        {
            throw new NotImplementedException();
        }

        public void Varaible(string var, int x)
        {
            throw new NotImplementedException();
        }

        public void DrawShape(string shapeType, params int[] p)
        {
            int[] list = new int[p.Length + 2];
            list[0] = xPos;
            list[1] = yPos;
            for (int i = 2; i < list.Length; i++)
                list[i] = p[i - 2];
            Shape shape = shapes.getShape(shapeType);
            shape.set(Color.Black, list);
            shape.draw(g, fill, pen, brush);
            log += "[" + DateTime.Now.ToString("T") + "] " + "Drew a " + shape.GetType().Name + " at (" + xPos + "," + yPos + ").\r\n";
        }

        public void WriteLog()
        {
            logBox.AppendText(log);
            log = "";
        }

        public void WriteError(String error)
        {
            logBox.SelectionColor = Color.Red;
            logBox.AppendText(error);
            logBox.SelectionColor = Color.Black;
        }
    }
}
